--
-- PostgreSQL database dump
--

-- Dumped from database version 11.3 (Debian 11.3-1.pgdg90+1)
-- Dumped by pg_dump version 11.3 (Debian 11.3-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account_emailaddress; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.account_emailaddress (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    verified boolean NOT NULL,
    "primary" boolean NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.account_emailaddress OWNER TO debug;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.account_emailaddress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailaddress_id_seq OWNER TO debug;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.account_emailaddress_id_seq OWNED BY public.account_emailaddress.id;


--
-- Name: account_emailconfirmation; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.account_emailconfirmation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    sent timestamp with time zone,
    key character varying(64) NOT NULL,
    email_address_id integer NOT NULL
);


ALTER TABLE public.account_emailconfirmation OWNER TO debug;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.account_emailconfirmation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailconfirmation_id_seq OWNER TO debug;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.account_emailconfirmation_id_seq OWNED BY public.account_emailconfirmation.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO debug;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO debug;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO debug;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO debug;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO debug;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO debug;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO debug;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO debug;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_celery_beat_clockedschedule; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_celery_beat_clockedschedule (
    id integer NOT NULL,
    clocked_time timestamp with time zone NOT NULL,
    enabled boolean NOT NULL
);


ALTER TABLE public.django_celery_beat_clockedschedule OWNER TO debug;

--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_celery_beat_clockedschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_clockedschedule_id_seq OWNER TO debug;

--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_celery_beat_clockedschedule_id_seq OWNED BY public.django_celery_beat_clockedschedule.id;


--
-- Name: django_celery_beat_crontabschedule; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_celery_beat_crontabschedule (
    id integer NOT NULL,
    minute character varying(240) NOT NULL,
    hour character varying(96) NOT NULL,
    day_of_week character varying(64) NOT NULL,
    day_of_month character varying(124) NOT NULL,
    month_of_year character varying(64) NOT NULL,
    timezone character varying(63) NOT NULL
);


ALTER TABLE public.django_celery_beat_crontabschedule OWNER TO debug;

--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_celery_beat_crontabschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_crontabschedule_id_seq OWNER TO debug;

--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_celery_beat_crontabschedule_id_seq OWNED BY public.django_celery_beat_crontabschedule.id;


--
-- Name: django_celery_beat_intervalschedule; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_celery_beat_intervalschedule (
    id integer NOT NULL,
    every integer NOT NULL,
    period character varying(24) NOT NULL
);


ALTER TABLE public.django_celery_beat_intervalschedule OWNER TO debug;

--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_celery_beat_intervalschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_intervalschedule_id_seq OWNER TO debug;

--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_celery_beat_intervalschedule_id_seq OWNED BY public.django_celery_beat_intervalschedule.id;


--
-- Name: django_celery_beat_periodictask; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_celery_beat_periodictask (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    task character varying(200) NOT NULL,
    args text NOT NULL,
    kwargs text NOT NULL,
    queue character varying(200),
    exchange character varying(200),
    routing_key character varying(200),
    expires timestamp with time zone,
    enabled boolean NOT NULL,
    last_run_at timestamp with time zone,
    total_run_count integer NOT NULL,
    date_changed timestamp with time zone NOT NULL,
    description text NOT NULL,
    crontab_id integer,
    interval_id integer,
    solar_id integer,
    one_off boolean NOT NULL,
    start_time timestamp with time zone,
    priority integer,
    headers text NOT NULL,
    clocked_id integer,
    CONSTRAINT django_celery_beat_periodictask_priority_check CHECK ((priority >= 0)),
    CONSTRAINT django_celery_beat_periodictask_total_run_count_check CHECK ((total_run_count >= 0))
);


ALTER TABLE public.django_celery_beat_periodictask OWNER TO debug;

--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_celery_beat_periodictask_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_periodictask_id_seq OWNER TO debug;

--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_celery_beat_periodictask_id_seq OWNED BY public.django_celery_beat_periodictask.id;


--
-- Name: django_celery_beat_periodictasks; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_celery_beat_periodictasks (
    ident smallint NOT NULL,
    last_update timestamp with time zone NOT NULL
);


ALTER TABLE public.django_celery_beat_periodictasks OWNER TO debug;

--
-- Name: django_celery_beat_solarschedule; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_celery_beat_solarschedule (
    id integer NOT NULL,
    event character varying(24) NOT NULL,
    latitude numeric(9,6) NOT NULL,
    longitude numeric(9,6) NOT NULL
);


ALTER TABLE public.django_celery_beat_solarschedule OWNER TO debug;

--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_celery_beat_solarschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_solarschedule_id_seq OWNER TO debug;

--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_celery_beat_solarschedule_id_seq OWNED BY public.django_celery_beat_solarschedule.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO debug;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO debug;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO debug;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO debug;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO debug;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO debug;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO debug;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: socialaccount_socialaccount; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.socialaccount_socialaccount (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    uid character varying(191) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    extra_data text NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialaccount OWNER TO debug;

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.socialaccount_socialaccount_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialaccount_id_seq OWNER TO debug;

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.socialaccount_socialaccount_id_seq OWNED BY public.socialaccount_socialaccount.id;


--
-- Name: socialaccount_socialapp; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.socialaccount_socialapp (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    name character varying(40) NOT NULL,
    client_id character varying(191) NOT NULL,
    secret character varying(191) NOT NULL,
    key character varying(191) NOT NULL
);


ALTER TABLE public.socialaccount_socialapp OWNER TO debug;

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.socialaccount_socialapp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_id_seq OWNER TO debug;

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.socialaccount_socialapp_id_seq OWNED BY public.socialaccount_socialapp.id;


--
-- Name: socialaccount_socialapp_sites; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.socialaccount_socialapp_sites (
    id integer NOT NULL,
    socialapp_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialapp_sites OWNER TO debug;

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.socialaccount_socialapp_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_sites_id_seq OWNER TO debug;

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.socialaccount_socialapp_sites_id_seq OWNED BY public.socialaccount_socialapp_sites.id;


--
-- Name: socialaccount_socialtoken; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.socialaccount_socialtoken (
    id integer NOT NULL,
    token text NOT NULL,
    token_secret text NOT NULL,
    expires_at timestamp with time zone,
    account_id integer NOT NULL,
    app_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialtoken OWNER TO debug;

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.socialaccount_socialtoken_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialtoken_id_seq OWNER TO debug;

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.socialaccount_socialtoken_id_seq OWNED BY public.socialaccount_socialtoken.id;


--
-- Name: users_corps; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_corps (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.users_corps OWNER TO debug;

--
-- Name: users_corps_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_corps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_corps_id_seq OWNER TO debug;

--
-- Name: users_corps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_corps_id_seq OWNED BY public.users_corps.id;


--
-- Name: users_document; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_document (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    physical_document character varying(100),
    reference character varying(255),
    request_id integer NOT NULL,
    document_category_id integer NOT NULL,
    provided_number integer NOT NULL,
    document_date date
);


ALTER TABLE public.users_document OWNER TO debug;

--
-- Name: users_document_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_document_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_document_id_seq OWNER TO debug;

--
-- Name: users_document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_document_id_seq OWNED BY public.users_document.id;


--
-- Name: users_documentcategory; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_documentcategory (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    required_number integer NOT NULL
);


ALTER TABLE public.users_documentcategory OWNER TO debug;

--
-- Name: users_documentcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_documentcategory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_documentcategory_id_seq OWNER TO debug;

--
-- Name: users_documentcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_documentcategory_id_seq OWNED BY public.users_documentcategory.id;


--
-- Name: users_grade; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_grade (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    corps_id integer NOT NULL,
    retired_to integer NOT NULL
);


ALTER TABLE public.users_grade OWNER TO debug;

--
-- Name: users_grade_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_grade_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_grade_id_seq OWNER TO debug;

--
-- Name: users_grade_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_grade_id_seq OWNED BY public.users_grade.id;


--
-- Name: users_ministry; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_ministry (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.users_ministry OWNER TO debug;

--
-- Name: users_ministry_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_ministry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_ministry_id_seq OWNER TO debug;

--
-- Name: users_ministry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_ministry_id_seq OWNED BY public.users_ministry.id;


--
-- Name: users_payingorg; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_payingorg (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.users_payingorg OWNER TO debug;

--
-- Name: users_payingorg_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_payingorg_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_payingorg_id_seq OWNER TO debug;

--
-- Name: users_payingorg_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_payingorg_id_seq OWNED BY public.users_payingorg.id;


--
-- Name: users_prepaymenttable; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_prepaymenttable (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    loan_amount double precision NOT NULL,
    duration double precision NOT NULL,
    monthly_withdrawal integer NOT NULL,
    recoverable_third_party double precision NOT NULL,
    minimal_salary double precision NOT NULL
);


ALTER TABLE public.users_prepaymenttable OWNER TO debug;

--
-- Name: users_prepaymenttable_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_prepaymenttable_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_prepaymenttable_id_seq OWNER TO debug;

--
-- Name: users_prepaymenttable_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_prepaymenttable_id_seq OWNED BY public.users_prepaymenttable.id;


--
-- Name: users_request; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_request (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    date date,
    post_reference character varying(20),
    observations text NOT NULL,
    category_id integer NOT NULL,
    amount_awarded double precision,
    amount_requested double precision NOT NULL,
    user_id integer NOT NULL,
    status character varying(100) NOT NULL,
    amount_to_repay double precision,
    monthly_payment_number double precision,
    quota double precision,
    withholding double precision,
    treatment_agent_id integer NOT NULL,
    treatment_date date
);


ALTER TABLE public.users_request OWNER TO debug;

--
-- Name: users_request_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_request_id_seq OWNER TO debug;

--
-- Name: users_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_request_id_seq OWNED BY public.users_request.id;


--
-- Name: users_requestcategory; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_requestcategory (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.users_requestcategory OWNER TO debug;

--
-- Name: users_requestcategory_documents; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_requestcategory_documents (
    id integer NOT NULL,
    requestcategory_id integer NOT NULL,
    documentcategory_id integer NOT NULL
);


ALTER TABLE public.users_requestcategory_documents OWNER TO debug;

--
-- Name: users_requestcategory_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_requestcategory_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_requestcategory_documents_id_seq OWNER TO debug;

--
-- Name: users_requestcategory_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_requestcategory_documents_id_seq OWNED BY public.users_requestcategory_documents.id;


--
-- Name: users_requestcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_requestcategory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_requestcategory_id_seq OWNER TO debug;

--
-- Name: users_requestcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_requestcategory_id_seq OWNED BY public.users_requestcategory.id;


--
-- Name: users_salary; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_salary (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    kind integer NOT NULL,
    amount double precision NOT NULL,
    change_at date
);


ALTER TABLE public.users_salary OWNER TO debug;

--
-- Name: users_salary_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_salary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_salary_id_seq OWNER TO debug;

--
-- Name: users_salary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_salary_id_seq OWNED BY public.users_salary.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    birth_date date,
    birth_place character varying(255),
    cni character varying(100),
    registration_date date,
    registration_number character varying(100),
    sex integer NOT NULL,
    retirement_age integer NOT NULL,
    address text NOT NULL,
    grade_id integer NOT NULL,
    ministry_id integer NOT NULL,
    paying_org_id integer NOT NULL,
    phone character varying(20) NOT NULL,
    postal_box character varying(20) NOT NULL,
    salary double precision NOT NULL
);


ALTER TABLE public.users_user OWNER TO debug;

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO debug;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_groups_id_seq OWNER TO debug;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_user_groups_id_seq OWNED BY public.users_user_groups.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO debug;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users_user.id;


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO debug;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_user_permissions_id_seq OWNER TO debug;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_user_user_permissions_id_seq OWNED BY public.users_user_user_permissions.id;


--
-- Name: account_emailaddress id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailaddress ALTER COLUMN id SET DEFAULT nextval('public.account_emailaddress_id_seq'::regclass);


--
-- Name: account_emailconfirmation id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailconfirmation ALTER COLUMN id SET DEFAULT nextval('public.account_emailconfirmation_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_celery_beat_clockedschedule id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_clockedschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_clockedschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_crontabschedule id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_crontabschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_crontabschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_intervalschedule id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_intervalschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_intervalschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_periodictask id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_periodictask ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_periodictask_id_seq'::regclass);


--
-- Name: django_celery_beat_solarschedule id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_solarschedule_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: socialaccount_socialaccount id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialaccount ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialaccount_id_seq'::regclass);


--
-- Name: socialaccount_socialapp id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_id_seq'::regclass);


--
-- Name: socialaccount_socialapp_sites id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_sites_id_seq'::regclass);


--
-- Name: socialaccount_socialtoken id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialtoken_id_seq'::regclass);


--
-- Name: users_corps id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_corps ALTER COLUMN id SET DEFAULT nextval('public.users_corps_id_seq'::regclass);


--
-- Name: users_document id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_document ALTER COLUMN id SET DEFAULT nextval('public.users_document_id_seq'::regclass);


--
-- Name: users_documentcategory id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_documentcategory ALTER COLUMN id SET DEFAULT nextval('public.users_documentcategory_id_seq'::regclass);


--
-- Name: users_grade id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_grade ALTER COLUMN id SET DEFAULT nextval('public.users_grade_id_seq'::regclass);


--
-- Name: users_ministry id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_ministry ALTER COLUMN id SET DEFAULT nextval('public.users_ministry_id_seq'::regclass);


--
-- Name: users_payingorg id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_payingorg ALTER COLUMN id SET DEFAULT nextval('public.users_payingorg_id_seq'::regclass);


--
-- Name: users_prepaymenttable id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_prepaymenttable ALTER COLUMN id SET DEFAULT nextval('public.users_prepaymenttable_id_seq'::regclass);


--
-- Name: users_request id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_request ALTER COLUMN id SET DEFAULT nextval('public.users_request_id_seq'::regclass);


--
-- Name: users_requestcategory id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_requestcategory ALTER COLUMN id SET DEFAULT nextval('public.users_requestcategory_id_seq'::regclass);


--
-- Name: users_requestcategory_documents id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_requestcategory_documents ALTER COLUMN id SET DEFAULT nextval('public.users_requestcategory_documents_id_seq'::regclass);


--
-- Name: users_salary id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_salary ALTER COLUMN id SET DEFAULT nextval('public.users_salary_id_seq'::regclass);


--
-- Name: users_user id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user ALTER COLUMN id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: users_user_groups id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups ALTER COLUMN id SET DEFAULT nextval('public.users_user_groups_id_seq'::regclass);


--
-- Name: users_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_user_user_permissions_id_seq'::regclass);


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
1	smgueye@smgueye.io	t	t	1
\.


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can view permission	1	view_permission
5	Can add group	2	add_group
6	Can change group	2	change_group
7	Can delete group	2	delete_group
8	Can view group	2	view_group
9	Can add content type	3	add_contenttype
10	Can change content type	3	change_contenttype
11	Can delete content type	3	delete_contenttype
12	Can view content type	3	view_contenttype
13	Can add session	4	add_session
14	Can change session	4	change_session
15	Can delete session	4	delete_session
16	Can view session	4	view_session
17	Can add site	5	add_site
18	Can change site	5	change_site
19	Can delete site	5	delete_site
20	Can view site	5	view_site
21	Can add log entry	6	add_logentry
22	Can change log entry	6	change_logentry
23	Can delete log entry	6	delete_logentry
24	Can view log entry	6	view_logentry
25	Can add email address	7	add_emailaddress
26	Can change email address	7	change_emailaddress
27	Can delete email address	7	delete_emailaddress
28	Can view email address	7	view_emailaddress
29	Can add email confirmation	8	add_emailconfirmation
30	Can change email confirmation	8	change_emailconfirmation
31	Can delete email confirmation	8	delete_emailconfirmation
32	Can view email confirmation	8	view_emailconfirmation
33	Can add social account	9	add_socialaccount
34	Can change social account	9	change_socialaccount
35	Can delete social account	9	delete_socialaccount
36	Can view social account	9	view_socialaccount
37	Can add social application	10	add_socialapp
38	Can change social application	10	change_socialapp
39	Can delete social application	10	delete_socialapp
40	Can view social application	10	view_socialapp
41	Can add social application token	11	add_socialtoken
42	Can change social application token	11	change_socialtoken
43	Can delete social application token	11	delete_socialtoken
44	Can view social application token	11	view_socialtoken
45	Can add crontab	12	add_crontabschedule
46	Can change crontab	12	change_crontabschedule
47	Can delete crontab	12	delete_crontabschedule
48	Can view crontab	12	view_crontabschedule
49	Can add interval	13	add_intervalschedule
50	Can change interval	13	change_intervalschedule
51	Can delete interval	13	delete_intervalschedule
52	Can view interval	13	view_intervalschedule
53	Can add periodic task	14	add_periodictask
54	Can change periodic task	14	change_periodictask
55	Can delete periodic task	14	delete_periodictask
56	Can view periodic task	14	view_periodictask
57	Can add periodic tasks	15	add_periodictasks
58	Can change periodic tasks	15	change_periodictasks
59	Can delete periodic tasks	15	delete_periodictasks
60	Can view periodic tasks	15	view_periodictasks
61	Can add solar event	16	add_solarschedule
62	Can change solar event	16	change_solarschedule
63	Can delete solar event	16	delete_solarschedule
64	Can view solar event	16	view_solarschedule
65	Can add clocked	17	add_clockedschedule
66	Can change clocked	17	change_clockedschedule
67	Can delete clocked	17	delete_clockedschedule
68	Can view clocked	17	view_clockedschedule
69	Can add user	18	add_user
70	Can change user	18	change_user
71	Can delete user	18	delete_user
72	Can view user	18	view_user
73	Can add corps	19	add_corps
74	Can change corps	19	change_corps
75	Can delete corps	19	delete_corps
76	Can view corps	19	view_corps
77	Can add document category	20	add_documentcategory
78	Can change document category	20	change_documentcategory
79	Can delete document category	20	delete_documentcategory
80	Can view document category	20	view_documentcategory
81	Can add ministry	21	add_ministry
82	Can change ministry	21	change_ministry
83	Can delete ministry	21	delete_ministry
84	Can view ministry	21	view_ministry
85	Can add paying org	22	add_payingorg
86	Can change paying org	22	change_payingorg
87	Can delete paying org	22	delete_payingorg
88	Can view paying org	22	view_payingorg
89	Can add salary	23	add_salary
90	Can change salary	23	change_salary
91	Can delete salary	23	delete_salary
92	Can view salary	23	view_salary
93	Can add request category	24	add_requestcategory
94	Can change request category	24	change_requestcategory
95	Can delete request category	24	delete_requestcategory
96	Can view request category	24	view_requestcategory
97	Can add request	25	add_request
98	Can change request	25	change_request
99	Can delete request	25	delete_request
100	Can view request	25	view_request
101	Can add document	26	add_document
102	Can change document	26	change_document
103	Can delete document	26	delete_document
104	Can view document	26	view_document
105	Can add additional information	27	add_additionalinformation
106	Can change additional information	27	change_additionalinformation
107	Can delete additional information	27	delete_additionalinformation
108	Can view additional information	27	view_additionalinformation
109	Can add grade	28	add_grade
110	Can change grade	28	change_grade
111	Can delete grade	28	delete_grade
112	Can view grade	28	view_grade
113	Can add prepayment table	29	add_prepaymenttable
114	Can change prepayment table	29	change_prepaymenttable
115	Can delete prepayment table	29	delete_prepaymenttable
116	Can view prepayment table	29	view_prepaymenttable
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2019-11-06 21:44:18.545522+00	1	smgueye	2	[{"changed": {"fields": ["birth_date"]}}]	18	1
\.


--
-- Data for Name: django_celery_beat_clockedschedule; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_celery_beat_clockedschedule (id, clocked_time, enabled) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_crontabschedule; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_celery_beat_crontabschedule (id, minute, hour, day_of_week, day_of_month, month_of_year, timezone) FROM stdin;
1	0	4	*	*	*	UTC
\.


--
-- Data for Name: django_celery_beat_intervalschedule; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_celery_beat_intervalschedule (id, every, period) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_periodictask; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_celery_beat_periodictask (id, name, task, args, kwargs, queue, exchange, routing_key, expires, enabled, last_run_at, total_run_count, date_changed, description, crontab_id, interval_id, solar_id, one_off, start_time, priority, headers, clocked_id) FROM stdin;
1	celery.backend_cleanup	celery.backend_cleanup	[]	{}	\N	\N	\N	\N	t	2019-11-06 08:45:07.435372+00	13	2019-11-06 21:42:31.11938+00		1	\N	\N	f	\N	\N	{}	\N
\.


--
-- Data for Name: django_celery_beat_periodictasks; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_celery_beat_periodictasks (ident, last_update) FROM stdin;
1	2019-11-06 21:42:31.116169+00
\.


--
-- Data for Name: django_celery_beat_solarschedule; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_celery_beat_solarschedule (id, event, latitude, longitude) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	auth	permission
2	auth	group
3	contenttypes	contenttype
4	sessions	session
5	sites	site
6	admin	logentry
7	account	emailaddress
8	account	emailconfirmation
9	socialaccount	socialaccount
10	socialaccount	socialapp
11	socialaccount	socialtoken
12	django_celery_beat	crontabschedule
13	django_celery_beat	intervalschedule
14	django_celery_beat	periodictask
15	django_celery_beat	periodictasks
16	django_celery_beat	solarschedule
17	django_celery_beat	clockedschedule
18	users	user
19	users	corps
20	users	documentcategory
21	users	ministry
22	users	payingorg
23	users	salary
24	users	requestcategory
25	users	request
26	users	document
27	users	additionalinformation
28	users	grade
29	users	prepaymenttable
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2019-10-18 20:06:01.635742+00
2	contenttypes	0002_remove_content_type_name	2019-10-18 20:06:01.658224+00
3	auth	0001_initial	2019-10-18 20:06:01.738336+00
4	auth	0002_alter_permission_name_max_length	2019-10-18 20:06:01.771465+00
5	auth	0003_alter_user_email_max_length	2019-10-18 20:06:01.788526+00
6	auth	0004_alter_user_username_opts	2019-10-18 20:06:01.809866+00
7	auth	0005_alter_user_last_login_null	2019-10-18 20:06:01.837223+00
8	auth	0006_require_contenttypes_0002	2019-10-18 20:06:01.844733+00
9	auth	0007_alter_validators_add_error_messages	2019-10-18 20:06:01.857829+00
10	auth	0008_alter_user_username_max_length	2019-10-18 20:06:01.892828+00
11	users	0001_initial	2019-10-18 20:06:01.936072+00
12	account	0001_initial	2019-10-18 20:06:02.09968+00
13	account	0002_email_max_length	2019-10-18 20:06:02.129586+00
14	admin	0001_initial	2019-10-18 20:06:02.179421+00
15	admin	0002_logentry_remove_auto_add	2019-10-18 20:06:02.272368+00
16	admin	0003_logentry_add_action_flag_choices	2019-10-18 20:06:02.289268+00
17	auth	0009_alter_user_last_name_max_length	2019-10-18 20:06:02.300701+00
18	auth	0010_alter_group_name_max_length	2019-10-18 20:06:02.312281+00
19	auth	0011_update_proxy_permissions	2019-10-18 20:06:02.325735+00
20	django_celery_beat	0001_initial	2019-10-18 20:06:02.356655+00
21	django_celery_beat	0002_auto_20161118_0346	2019-10-18 20:06:02.381949+00
22	django_celery_beat	0003_auto_20161209_0049	2019-10-18 20:06:02.398364+00
23	django_celery_beat	0004_auto_20170221_0000	2019-10-18 20:06:02.406174+00
24	django_celery_beat	0005_add_solarschedule_events_choices	2019-10-18 20:06:02.414113+00
25	django_celery_beat	0006_auto_20180322_0932	2019-10-18 20:06:02.445457+00
26	django_celery_beat	0007_auto_20180521_0826	2019-10-18 20:06:02.460054+00
27	django_celery_beat	0008_auto_20180914_1922	2019-10-18 20:06:02.485033+00
28	django_celery_beat	0006_auto_20180210_1226	2019-10-18 20:06:02.630671+00
29	django_celery_beat	0006_periodictask_priority	2019-10-18 20:06:02.645367+00
30	django_celery_beat	0009_periodictask_headers	2019-10-18 20:06:02.656694+00
31	django_celery_beat	0010_auto_20190429_0326	2019-10-18 20:06:02.845767+00
32	django_celery_beat	0011_auto_20190508_0153	2019-10-18 20:06:02.863626+00
33	sessions	0001_initial	2019-10-18 20:06:02.879465+00
34	sites	0001_initial	2019-10-18 20:06:02.897274+00
35	sites	0002_alter_domain_unique	2019-10-18 20:06:02.909265+00
36	sites	0003_set_site_domain_and_name	2019-10-18 20:06:02.935106+00
37	socialaccount	0001_initial	2019-10-18 20:06:03.008406+00
38	socialaccount	0002_token_max_lengths	2019-10-18 20:06:03.067949+00
39	socialaccount	0003_extra_data_default_dict	2019-10-18 20:06:03.082354+00
40	users	0002_auto_20191019_0120	2019-10-19 01:20:46.183984+00
41	users	0003_auto_20191019_0150	2019-10-19 01:51:09.081057+00
42	users	0004_auto_20191023_2147	2019-10-23 21:47:47.570124+00
43	users	0005_auto_20191028_1437	2019-10-28 14:37:41.289394+00
44	users	0006_auto_20191028_1519	2019-10-28 15:19:31.800877+00
45	users	0007_grade	2019-10-31 15:55:02.597654+00
46	users	0008_grade_corps	2019-10-31 16:04:09.741911+00
79	users	0009_grade_retired_to	2019-10-31 16:15:48.884261+00
80	users	0010_auto_20191031_1617	2019-10-31 16:17:39.379295+00
81	users	0011_auto_20191103_1758	2019-11-03 17:58:31.087571+00
82	users	0012_auto_20191104_0442	2019-11-04 04:42:26.11903+00
83	users	0013_auto_20191104_0443	2019-11-04 04:43:47.806733+00
84	users	0014_request_user	2019-11-04 04:47:06.94072+00
85	users	0015_request_status	2019-11-04 10:27:21.10193+00
86	users	0016_auto_20191104_1940	2019-11-04 19:40:52.775298+00
87	users	0017_auto_20191105_1123	2019-11-05 11:23:34.17233+00
88	users	0018_auto_20191105_1126	2019-11-05 11:27:04.560709+00
89	users	0019_auto_20191105_1217	2019-11-05 12:23:17.076739+00
90	users	0020_document_document_date	2019-11-05 17:03:39.442595+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
awi3x2le2dtf4f2uglcc3l8fx4i808yk	ZmJmZDQ1NTdiNmZmODU3MmU3MDQ2YjA5NThlZWU0ZDE4NWQzMWY3NDp7Il9zZXNzaW9uX2V4cGlyeSI6MCwiX2F1dGhfdXNlcl9pZCI6IjEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6Ijg3YWM4M2Q2NTdkMmQ3ZWViNGY4MWFkN2FkYmVlZGFlMDlhZmI1ODUifQ==	2019-11-02 01:42:15.634727+00
wauyiz0jwx6dx5wz8x23qqw87pge70t9	MDc3N2JmZjE2ZDNkYjljZThmYTZhY2Q2YTA1YjkxODc2NDRlODcyYTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjNDhkMDgyNDM3ZDgxYzJiNGRlZjQ1ZmFlZjkzOTNhZDIwMGRmNGNlIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2019-11-07 13:29:33.626027+00
axme7mn2xguykxbsqopg0tmdw2qv4oho	MDc3N2JmZjE2ZDNkYjljZThmYTZhY2Q2YTA1YjkxODc2NDRlODcyYTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjNDhkMDgyNDM3ZDgxYzJiNGRlZjQ1ZmFlZjkzOTNhZDIwMGRmNGNlIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2019-11-08 20:11:29.796225+00
mgi94skv9i2q1wvvzijwvjiyuy1m9z4d	MDc3N2JmZjE2ZDNkYjljZThmYTZhY2Q2YTA1YjkxODc2NDRlODcyYTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjNDhkMDgyNDM3ZDgxYzJiNGRlZjQ1ZmFlZjkzOTNhZDIwMGRmNGNlIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2019-11-11 11:01:12.264443+00
isw2etv1sw9ix2dv9mejkp34yk2f9m1i	MDc3N2JmZjE2ZDNkYjljZThmYTZhY2Q2YTA1YjkxODc2NDRlODcyYTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjNDhkMDgyNDM3ZDgxYzJiNGRlZjQ1ZmFlZjkzOTNhZDIwMGRmNGNlIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2019-11-13 15:55:40.722888+00
e4nthpxvmth1k36nkh248kdt6n244hpa	MDc3N2JmZjE2ZDNkYjljZThmYTZhY2Q2YTA1YjkxODc2NDRlODcyYTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjNDhkMDgyNDM3ZDgxYzJiNGRlZjQ1ZmFlZjkzOTNhZDIwMGRmNGNlIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2019-11-19 14:10:48.59004+00
qrnf1txr8d8jgkvaeml87x8vocvl7hr4	MDc3N2JmZjE2ZDNkYjljZThmYTZhY2Q2YTA1YjkxODc2NDRlODcyYTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjNDhkMDgyNDM3ZDgxYzJiNGRlZjQ1ZmFlZjkzOTNhZDIwMGRmNGNlIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2019-11-20 16:41:02.915826+00
2st85rho8h5knd3yolsvg35ytiszhwf9	MDc3N2JmZjE2ZDNkYjljZThmYTZhY2Q2YTA1YjkxODc2NDRlODcyYTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjNDhkMDgyNDM3ZDgxYzJiNGRlZjQ1ZmFlZjkzOTNhZDIwMGRmNGNlIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2019-11-20 22:06:26.252452+00
t9tzd4g1uzt7hlwu5ddosge0k6bgkbmk	MDc3N2JmZjE2ZDNkYjljZThmYTZhY2Q2YTA1YjkxODc2NDRlODcyYTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjNDhkMDgyNDM3ZDgxYzJiNGRlZjQ1ZmFlZjkzOTNhZDIwMGRmNGNlIiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2019-11-20 22:09:27.006788+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_site (id, domain, name) FROM stdin;
1	sigfip.herokuapp.com	sigfip
\.


--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM stdin;
\.


--
-- Data for Name: users_corps; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_corps (id, name, description) FROM stdin;
2	ADMINISTRATION PENITENTIAIRE	_
5	EAUX ET FORETS	_
6	GENDARMERIE	_
7	ARMEE	_
3	DOUANE	_
8	SAPEURS POMPIERS	_
9	POLICE	_
10	SERVICE D'HYGIENE	_
11	SANTE	_
12	ENSEIGNEMENT	_
13	ADMINISTRATION	_
\.


--
-- Data for Name: users_document; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_document (id, created_at, updated_at, physical_document, reference, request_id, document_category_id, provided_number, document_date) FROM stdin;
1	2019-11-05 14:32:54.451107+00	2019-11-06 22:34:52.618703+00		_ _	2	1	2	2019-11-05
2	2019-11-05 14:32:56.128889+00	2019-11-06 22:34:53.368748+00		- -	2	2	2	2019-10-05
3	2019-11-05 14:32:57.740106+00	2019-11-06 22:34:54.056521+00		__	2	3	2	2019-09-05
4	2019-11-05 14:32:59.504955+00	2019-11-06 22:34:54.681991+00		--	2	4	2	2019-08-05
\.


--
-- Data for Name: users_documentcategory; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_documentcategory (id, name, description, created_at, updated_at, required_number) FROM stdin;
1	Bulletin de scide	__	2019-10-31 18:46:43.30063+00	2019-10-31 18:46:51.832968+00	2
2	Photocopie CNI	_	2019-10-31 19:06:35.191486+00	2019-10-31 19:06:35.191838+00	2
3	Demande manuscrite	__	2019-10-31 19:06:58.694779+00	2019-10-31 19:06:58.695191+00	2
4	Enveloppes timbrées	_	2019-10-31 19:07:31.813168+00	2019-10-31 19:07:31.81356+00	2
\.


--
-- Data for Name: users_grade; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_grade (id, name, description, corps_id, retired_to) FROM stdin;
1	Surveillant de Prison	_	2	55
2	Brigadier de Prison	_	2	55
3	Préposé des Douanes	_	3	55
5	Lieutenant des Eaux et Forêts	_	5	60
\.


--
-- Data for Name: users_ministry; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_ministry (id, name, description) FROM stdin;
1	Présidence de la République.	_
2	Primature	_
\.


--
-- Data for Name: users_payingorg; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_payingorg (id, name, description, created_at, updated_at) FROM stdin;
1	Mairie de Dakar	_	2019-10-31 18:10:19.223323+00	2019-10-31 18:10:19.223677+00
2	Mairie de Koumpentoum	_	2019-10-31 18:10:33.084079+00	2019-10-31 18:10:33.084569+00
3	Mairie de Saint Louis	_	2019-10-31 18:10:41.501872+00	2019-10-31 18:12:21.51558+00
\.


--
-- Data for Name: users_prepaymenttable; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_prepaymenttable (id, created_at, updated_at, loan_amount, duration, monthly_withdrawal, recoverable_third_party, minimal_salary) FROM stdin;
1	2019-11-05 12:32:50.339125+00	2019-11-05 12:32:50.339641+00	1000000	4	20834	62502	92502
2	2019-11-05 12:33:46.998856+00	2019-11-05 12:33:46.999292+00	1500000	4	31250	93750	123750
3	2019-11-05 12:34:27.339973+00	2019-11-05 12:34:27.340325+00	2000000	4	41667	125001	155001
4	2019-11-05 12:35:12.209224+00	2019-11-05 12:35:12.209678+00	2500000	5	41667	125001	155001
5	2019-11-05 12:35:26.564013+00	2019-11-05 12:36:35.697868+00	3000000	5	50000	150000	180000
\.


--
-- Data for Name: users_request; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_request (id, created_at, updated_at, date, post_reference, observations, category_id, amount_awarded, amount_requested, user_id, status, amount_to_repay, monthly_payment_number, quota, withholding, treatment_agent_id, treatment_date) FROM stdin;
2	2019-11-05 14:32:52.737521+00	2019-11-06 22:34:51.993525+00	2019-08-05	\N	NEANT	1	1000000	1000000	1	accepted	1000000	48	30834	20833.3333333333321	1	2019-11-05
\.


--
-- Data for Name: users_requestcategory; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_requestcategory (id, name, description, created_at, updated_at) FROM stdin;
2	Demande de prêt equipement	_	2019-10-31 18:29:50.943522+00	2019-10-31 18:29:50.943873+00
4	Demande de prêt divers	_	2019-10-31 18:30:23.745648+00	2019-10-31 18:30:48.877631+00
1	Demande de prêt au logement	_	2019-10-31 18:29:36.499806+00	2019-11-04 02:19:38.789456+00
\.


--
-- Data for Name: users_requestcategory_documents; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_requestcategory_documents (id, requestcategory_id, documentcategory_id) FROM stdin;
1	1	1
2	1	2
3	1	3
4	1	4
\.


--
-- Data for Name: users_salary; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_salary (id, created_at, updated_at, kind, amount, change_at) FROM stdin;
\.


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, birth_date, birth_place, cni, registration_date, registration_number, sex, retirement_age, address, grade_id, ministry_id, paying_org_id, phone, postal_box, salary) FROM stdin;
1	argon2$argon2i$v=19$m=512,t=2,p=2$U01hUDlZbWJIZFFC$HGzlv9LgibWGbzGsd14K/A	2019-11-06 22:09:26.616439+00	t	smgueye	Seydina Mouhamed	Gueye	smgueye@smgueye.io	t	t	2019-10-18 22:45:32+00	1991-08-31			\N		1	60	Dakar, Senegal	1	1	1	2210000000	0	92502
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 1, true);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 116, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, true);


--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_celery_beat_clockedschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_celery_beat_crontabschedule_id_seq', 33, true);


--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_celery_beat_intervalschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_celery_beat_periodictask_id_seq', 33, true);


--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_celery_beat_solarschedule_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 29, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 90, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, false);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.socialaccount_socialaccount_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_sites_id_seq', 1, false);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.socialaccount_socialtoken_id_seq', 1, false);


--
-- Name: users_corps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_corps_id_seq', 14, true);


--
-- Name: users_document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_document_id_seq', 4, true);


--
-- Name: users_documentcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_documentcategory_id_seq', 5, true);


--
-- Name: users_grade_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_grade_id_seq', 6, true);


--
-- Name: users_ministry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_ministry_id_seq', 3, true);


--
-- Name: users_payingorg_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_payingorg_id_seq', 5, true);


--
-- Name: users_prepaymenttable_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_prepaymenttable_id_seq', 6, true);


--
-- Name: users_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_request_id_seq', 2, true);


--
-- Name: users_requestcategory_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_requestcategory_documents_id_seq', 4, true);


--
-- Name: users_requestcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_requestcategory_id_seq', 4, true);


--
-- Name: users_salary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_salary_id_seq', 1, false);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_user_id_seq', 1, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- Name: account_emailaddress account_emailaddress_email_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_email_key UNIQUE (email);


--
-- Name: account_emailaddress account_emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_pkey PRIMARY KEY (id);


--
-- Name: account_emailconfirmation account_emailconfirmation_key_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_key_key UNIQUE (key);


--
-- Name: account_emailconfirmation account_emailconfirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_clockedschedule django_celery_beat_clockedschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_clockedschedule
    ADD CONSTRAINT django_celery_beat_clockedschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_crontabschedule django_celery_beat_crontabschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_crontabschedule
    ADD CONSTRAINT django_celery_beat_crontabschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_intervalschedule django_celery_beat_intervalschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_intervalschedule
    ADD CONSTRAINT django_celery_beat_intervalschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_name_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_name_key UNIQUE (name);


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_periodictasks django_celery_beat_periodictasks_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_periodictasks
    ADD CONSTRAINT django_celery_beat_periodictasks_pkey PRIMARY KEY (ident);


--
-- Name: django_celery_beat_solarschedule django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule
    ADD CONSTRAINT django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq UNIQUE (event, latitude, longitude);


--
-- Name: django_celery_beat_solarschedule django_celery_beat_solarschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule
    ADD CONSTRAINT django_celery_beat_solarschedule_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_provider_uid_fc810c6e_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_provider_uid_fc810c6e_uniq UNIQUE (provider, uid);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq UNIQUE (socialapp_id, site_id);


--
-- Name: socialaccount_socialapp socialaccount_socialapp_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp
    ADD CONSTRAINT socialaccount_socialapp_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp_sites_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq UNIQUE (app_id, account_id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_pkey PRIMARY KEY (id);


--
-- Name: users_corps users_corps_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_corps
    ADD CONSTRAINT users_corps_pkey PRIMARY KEY (id);


--
-- Name: users_document users_document_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_document
    ADD CONSTRAINT users_document_pkey PRIMARY KEY (id);


--
-- Name: users_documentcategory users_documentcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_documentcategory
    ADD CONSTRAINT users_documentcategory_pkey PRIMARY KEY (id);


--
-- Name: users_grade users_grade_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_grade
    ADD CONSTRAINT users_grade_pkey PRIMARY KEY (id);


--
-- Name: users_ministry users_ministry_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_ministry
    ADD CONSTRAINT users_ministry_pkey PRIMARY KEY (id);


--
-- Name: users_payingorg users_payingorg_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_payingorg
    ADD CONSTRAINT users_payingorg_pkey PRIMARY KEY (id);


--
-- Name: users_prepaymenttable users_prepaymenttable_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_prepaymenttable
    ADD CONSTRAINT users_prepaymenttable_pkey PRIMARY KEY (id);


--
-- Name: users_request users_request_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_request
    ADD CONSTRAINT users_request_pkey PRIMARY KEY (id);


--
-- Name: users_requestcategory_documents users_requestcategory_do_requestcategory_id_docum_492a2fc1_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_requestcategory_documents
    ADD CONSTRAINT users_requestcategory_do_requestcategory_id_docum_492a2fc1_uniq UNIQUE (requestcategory_id, documentcategory_id);


--
-- Name: users_requestcategory_documents users_requestcategory_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_requestcategory_documents
    ADD CONSTRAINT users_requestcategory_documents_pkey PRIMARY KEY (id);


--
-- Name: users_requestcategory users_requestcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_requestcategory
    ADD CONSTRAINT users_requestcategory_pkey PRIMARY KEY (id);


--
-- Name: users_salary users_salary_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_salary
    ADD CONSTRAINT users_salary_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: account_emailaddress_email_03be32b2_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX account_emailaddress_email_03be32b2_like ON public.account_emailaddress USING btree (email varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id_2c513194; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX account_emailaddress_user_id_2c513194 ON public.account_emailaddress USING btree (user_id);


--
-- Name: account_emailconfirmation_email_address_id_5b7f8c58; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX account_emailconfirmation_email_address_id_5b7f8c58 ON public.account_emailconfirmation USING btree (email_address_id);


--
-- Name: account_emailconfirmation_key_f43612bd_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX account_emailconfirmation_key_f43612bd_like ON public.account_emailconfirmation USING btree (key varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_celery_beat_periodictask_clocked_id_47a69f82; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_celery_beat_periodictask_clocked_id_47a69f82 ON public.django_celery_beat_periodictask USING btree (clocked_id);


--
-- Name: django_celery_beat_periodictask_crontab_id_d3cba168; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_celery_beat_periodictask_crontab_id_d3cba168 ON public.django_celery_beat_periodictask USING btree (crontab_id);


--
-- Name: django_celery_beat_periodictask_interval_id_a8ca27da; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_celery_beat_periodictask_interval_id_a8ca27da ON public.django_celery_beat_periodictask USING btree (interval_id);


--
-- Name: django_celery_beat_periodictask_name_265a36b7_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_celery_beat_periodictask_name_265a36b7_like ON public.django_celery_beat_periodictask USING btree (name varchar_pattern_ops);


--
-- Name: django_celery_beat_periodictask_solar_id_a87ce72c; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_celery_beat_periodictask_solar_id_a87ce72c ON public.django_celery_beat_periodictask USING btree (solar_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: socialaccount_socialaccount_user_id_8146e70c; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialaccount_user_id_8146e70c ON public.socialaccount_socialaccount USING btree (user_id);


--
-- Name: socialaccount_socialapp_sites_site_id_2579dee5; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialapp_sites_site_id_2579dee5 ON public.socialaccount_socialapp_sites USING btree (site_id);


--
-- Name: socialaccount_socialapp_sites_socialapp_id_97fb6e7d; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialapp_sites_socialapp_id_97fb6e7d ON public.socialaccount_socialapp_sites USING btree (socialapp_id);


--
-- Name: socialaccount_socialtoken_account_id_951f210e; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialtoken_account_id_951f210e ON public.socialaccount_socialtoken USING btree (account_id);


--
-- Name: socialaccount_socialtoken_app_id_636a42d7; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialtoken_app_id_636a42d7 ON public.socialaccount_socialtoken USING btree (app_id);


--
-- Name: users_document_document_category_id_f3b97bd9; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_document_document_category_id_f3b97bd9 ON public.users_document USING btree (document_category_id);


--
-- Name: users_document_request_id_dba9f6a1; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_document_request_id_dba9f6a1 ON public.users_document USING btree (request_id);


--
-- Name: users_grade_corps_id_8c0e14b0; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_grade_corps_id_8c0e14b0 ON public.users_grade USING btree (corps_id);


--
-- Name: users_request_category_id_820ea2a7; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_request_category_id_820ea2a7 ON public.users_request USING btree (category_id);


--
-- Name: users_request_treatment_agent_id_d5b387c1; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_request_treatment_agent_id_d5b387c1 ON public.users_request USING btree (treatment_agent_id);


--
-- Name: users_request_user_id_0bbf78c4; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_request_user_id_0bbf78c4 ON public.users_request USING btree (user_id);


--
-- Name: users_requestcategory_documents_documentcategory_id_46ea1f54; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_requestcategory_documents_documentcategory_id_46ea1f54 ON public.users_requestcategory_documents USING btree (documentcategory_id);


--
-- Name: users_requestcategory_documents_requestcategory_id_950ecd21; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_requestcategory_documents_requestcategory_id_950ecd21 ON public.users_requestcategory_documents USING btree (requestcategory_id);


--
-- Name: users_user_grade_id_dc199378; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_grade_id_dc199378 ON public.users_user USING btree (grade_id);


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_ministry_id_30b20d41; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_ministry_id_30b20d41 ON public.users_user USING btree (ministry_id);


--
-- Name: users_user_paying_org_id_b2e67866; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_paying_org_id_b2e67866 ON public.users_user USING btree (paying_org_id);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: account_emailaddress account_emailaddress_user_id_2c513194_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_2c513194_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_emailconfirmation account_emailconfirm_email_address_id_5b7f8c58_fk_account_e; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirm_email_address_id_5b7f8c58_fk_account_e FOREIGN KEY (email_address_id) REFERENCES public.account_emailaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_clocked_id_47a69f82_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_clocked_id_47a69f82_fk_django_ce FOREIGN KEY (clocked_id) REFERENCES public.django_celery_beat_clockedschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_crontab_id_d3cba168_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_crontab_id_d3cba168_fk_django_ce FOREIGN KEY (crontab_id) REFERENCES public.django_celery_beat_crontabschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_interval_id_a8ca27da_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_interval_id_a8ca27da_fk_django_ce FOREIGN KEY (interval_id) REFERENCES public.django_celery_beat_intervalschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_solar_id_a87ce72c_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_solar_id_a87ce72c_fk_django_ce FOREIGN KEY (solar_id) REFERENCES public.django_celery_beat_solarschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_account_id_951f210e_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_account_id_951f210e_fk_socialacc FOREIGN KEY (account_id) REFERENCES public.socialaccount_socialaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_app_id_636a42d7_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_app_id_636a42d7_fk_socialacc FOREIGN KEY (app_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_site_id_2579dee5_fk_django_si; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_site_id_2579dee5_fk_django_si FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc FOREIGN KEY (socialapp_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_document users_document_document_category_id_f3b97bd9_fk_users_doc; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_document
    ADD CONSTRAINT users_document_document_category_id_f3b97bd9_fk_users_doc FOREIGN KEY (document_category_id) REFERENCES public.users_documentcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_document users_document_request_id_dba9f6a1_fk_users_request_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_document
    ADD CONSTRAINT users_document_request_id_dba9f6a1_fk_users_request_id FOREIGN KEY (request_id) REFERENCES public.users_request(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_grade users_grade_corps_id_8c0e14b0_fk_users_corps_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_grade
    ADD CONSTRAINT users_grade_corps_id_8c0e14b0_fk_users_corps_id FOREIGN KEY (corps_id) REFERENCES public.users_corps(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_request users_request_category_id_820ea2a7_fk_users_requestcategory_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_request
    ADD CONSTRAINT users_request_category_id_820ea2a7_fk_users_requestcategory_id FOREIGN KEY (category_id) REFERENCES public.users_requestcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_request users_request_treatment_agent_id_d5b387c1_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_request
    ADD CONSTRAINT users_request_treatment_agent_id_d5b387c1_fk_users_user_id FOREIGN KEY (treatment_agent_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_request users_request_user_id_0bbf78c4_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_request
    ADD CONSTRAINT users_request_user_id_0bbf78c4_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_requestcategory_documents users_requestcategor_documentcategory_id_46ea1f54_fk_users_doc; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_requestcategory_documents
    ADD CONSTRAINT users_requestcategor_documentcategory_id_46ea1f54_fk_users_doc FOREIGN KEY (documentcategory_id) REFERENCES public.users_documentcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_requestcategory_documents users_requestcategor_requestcategory_id_950ecd21_fk_users_req; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_requestcategory_documents
    ADD CONSTRAINT users_requestcategor_requestcategory_id_950ecd21_fk_users_req FOREIGN KEY (requestcategory_id) REFERENCES public.users_requestcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user users_user_grade_id_dc199378_fk_users_grade_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_grade_id_dc199378_fk_users_grade_id FOREIGN KEY (grade_id) REFERENCES public.users_grade(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user users_user_ministry_id_30b20d41_fk_users_ministry_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_ministry_id_30b20d41_fk_users_ministry_id FOREIGN KEY (ministry_id) REFERENCES public.users_ministry(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user users_user_paying_org_id_b2e67866_fk_users_payingorg_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_paying_org_id_b2e67866_fk_users_payingorg_id FOREIGN KEY (paying_org_id) REFERENCES public.users_payingorg(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

